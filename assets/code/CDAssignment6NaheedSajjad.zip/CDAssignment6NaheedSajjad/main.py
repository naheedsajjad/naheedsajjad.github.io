# Assignment6_NaheedSajjad
import requests
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, ScatterChart, PieChart, Reference

# 1. Fetch data from CoinCap API

url = "https://rest.coincap.io/v3/assets?apiKey=2c2464166488533788dceb9e092dd8df607a7ff75ec4f358bd17aaa2143986b8"
response = requests.get(url)
data = response.json()['data']

# Select top 10 cryptocurrencies
top_assets = data[:10]

# 2. Create Excel workbook and sheet

wb = Workbook()
ws = wb.active
ws.title = "Crypto Data"

# Define headers
headers = ["Rank", "Name", "Symbol", "Price (USD)", "Market Cap (USD)", "Volume (24Hr)", "Change (24Hr %)"]
ws.append(headers)

# Add data rows
for asset in top_assets:
    ws.append([
        int(asset['rank']),
        asset['name'],
        asset['symbol'],
        float(asset['priceUsd']),
        float(asset['marketCapUsd']),
        float(asset['volumeUsd24Hr']),
        float(asset['changePercent24Hr'])
    ])

# ---- Bar Chart: Market Cap ----
bar_chart = BarChart()
bar_chart.title = "Market Cap (Top 10 Cryptos)"
bar_chart.y_axis.title = "Market Cap (USD)"
bar_chart.x_axis.title = "Cryptocurrency"
data_ref = Reference(ws, min_col=5, min_row=1, max_row=11)
cats_ref = Reference(ws, min_col=2, min_row=2, max_row=11)
bar_chart.add_data(data_ref, titles_from_data=True)
bar_chart.set_categories(cats_ref)
ws.add_chart(bar_chart, "I2")

# ---- Line Chart: Price ----
line_chart = LineChart()
line_chart.title = "Price (USD)"
line_chart.y_axis.title = "Price (USD)"
data_ref = Reference(ws, min_col=4, min_row=1, max_row=11)
line_chart.add_data(data_ref, titles_from_data=True)
line_chart.set_categories(cats_ref)
ws.add_chart(line_chart, "I20")

# ---- Scatter Chart: Market Cap vs Volume ----
scatter_chart = ScatterChart()
scatter_chart.title = "Market Cap vs Volume"
scatter_chart.x_axis.title = "Market Cap (USD)"
scatter_chart.y_axis.title = "Volume (24Hr)"
x_values = Reference(ws, min_col=5, min_row=2, max_row=11)
y_values = Reference(ws, min_col=6, min_row=2, max_row=11)
scatter_chart.add_data(y_values, titles_from_data=False)
scatter_chart.set_categories(x_values)
ws.add_chart(scatter_chart, "I38")

# ---- Pie Chart: Market Share by Market Cap ----
pie_chart = PieChart()
pie_chart.title = "Market Share by Market Cap"
data_ref = Reference(ws, min_col=5, min_row=1, max_row=11)
cats_ref = Reference(ws, min_col=2, min_row=2, max_row=11)
pie_chart.add_data(data_ref, titles_from_data=True)
pie_chart.set_categories(cats_ref)
ws.add_chart(pie_chart, "I56")

# 4. Save the Workbook

output_filename = "Crypto_Market_Charts.xlsx"
wb.save(output_filename)


